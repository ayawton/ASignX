import React, { useState, useEffect } from 'react';
import { ActiveTab, LessonTrack, UserProgress } from './types';
import { ASL_SIGNS, LESSON_TRACKS, INITIAL_USER_PROGRESS } from './data/aslData';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { HeroBanner } from './components/HeroBanner';
import { PracticeStudioShell } from './components/PracticeStudioShell';
import { SignDictionary } from './components/SignDictionary';
import { QuizArena } from './components/QuizArena';
import { AuthPage } from './components/AuthPage';
import { LessonCards } from './components/LessonCards';
import { ColorPaletteReference } from './components/ColorPaletteReference';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedSignId, setSelectedSignId] = useState<string>('asl-a');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [highContrast, setHighContrast] = useState<boolean>(false);
  const [userProgress, setUserProgress] = useState<UserProgress>(INITIAL_USER_PROGRESS);

  // Sync dark mode class on document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle direct navigation to practice studio with a specific sign
  const handleSelectSignForPractice = (signId: string) => {
    setSelectedSignId(signId);
    setActiveTab('practice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle starting a lesson track
  const handleStartTrack = (track: LessonTrack) => {
    const firstSign = ASL_SIGNS.find((s) => s.category === track.category) || ASL_SIGNS[0];
    setSelectedSignId(firstSign.id);
    setActiveTab('practice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 flex flex-col font-sans ${
        darkMode ? 'bg-[#101926] text-[#FFFFFF]' : 'bg-[#F7F8FA] text-[#111827]'
      } ${highContrast ? 'contrast-125' : ''}`}
    >
      {/* Header with fss2.png logo and fss.png navigation style */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        highContrast={highContrast}
        setHighContrast={setHighContrast}
        userProgress={userProgress}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <LandingPage
            onStartInterpreting={() => {
              setActiveTab('practice');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onExploreDictionary={() => {
              setActiveTab('dictionary');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onStartQuiz={() => {
              setActiveTab('quiz');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            darkMode={darkMode}
            onNavigateTab={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'learn' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 animate-fade-in">
            {/* Hero & Progress Section */}
            <HeroBanner
              userProgress={userProgress}
              setActiveTab={setActiveTab}
              onSelectSignForPractice={handleSelectSignForPractice}
              darkMode={darkMode}
            />

            {/* Curriculum Tracks */}
            <LessonCards
              tracks={LESSON_TRACKS}
              onStartTrack={handleStartTrack}
              darkMode={darkMode}
            />

            {/* Color Palette & Accessibility Reference */}
            <ColorPaletteReference darkMode={darkMode} />
          </div>
        )}

        {activeTab === 'practice' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 animate-fade-in">
            {/* Dedicated ASL Recognition Studio Shell */}
            <PracticeStudioShell
              signs={ASL_SIGNS}
              selectedSignId={selectedSignId}
              onSelectSign={setSelectedSignId}
              darkMode={darkMode}
            />

            {/* Color Palette Reference */}
            <ColorPaletteReference darkMode={darkMode} />
          </div>
        )}

        {activeTab === 'dictionary' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 animate-fade-in">
            {/* Searchable ASL Sign Reference */}
            <SignDictionary
              signs={ASL_SIGNS}
              onSelectSignForPractice={handleSelectSignForPractice}
              darkMode={darkMode}
            />

            {/* Color Palette Reference */}
            <ColorPaletteReference darkMode={darkMode} />
          </div>
        )}

        {activeTab === 'quiz' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 animate-fade-in">
            {/* Knowledge Check Quiz */}
            <QuizArena
              onSelectSignForPractice={handleSelectSignForPractice}
              darkMode={darkMode}
            />

            {/* Color Palette Reference */}
            <ColorPaletteReference darkMode={darkMode} />
          </div>
        )}

        {(activeTab === 'login' || activeTab === 'register') && (
          <div className="w-full animate-fade-in">
            <AuthPage
              initialMode={activeTab === 'register' ? 'register' : 'login'}
              onNavigateTab={(tab) => {
                setActiveTab(tab);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              darkMode={darkMode}
            />
          </div>
        )}
      </main>

      {/* Footer matching fss.png */}
      <Footer setActiveTab={setActiveTab} darkMode={darkMode} />
    </div>
  );
}
