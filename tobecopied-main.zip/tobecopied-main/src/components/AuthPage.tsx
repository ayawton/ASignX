import React, { useState } from 'react';
import { ActiveTab } from '../types';
import { SignSpellLogo } from './SignSpellLogo';
import { Mail, Lock, User, Eye, EyeOff, Check, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';

interface AuthPageProps {
  initialMode?: 'login' | 'register';
  onNavigateTab: (tab: ActiveTab) => void;
  darkMode: boolean;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  initialMode = 'login',
  onNavigateTab,
  darkMode,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Form states (Shell presentation only, functionality not yet added as requested)
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);

  const [simulatedFeedback, setSimulatedFeedback] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSimulatedFeedback(
      mode === 'login'
        ? 'Login shell submitted! (Backend authentication hook will be connected in upcoming phase).'
        : 'Registration shell submitted! (User database registration hook will be connected in upcoming phase).'
    );
    setTimeout(() => {
      setSimulatedFeedback(null);
    }, 4000);
  };

  return (
    <div
      id="auth-page-container"
      className="min-h-[calc(100vh-5rem)] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12"
      style={{ backgroundColor: '#0D1522' }}
    >
      {/* Background dot matrix */}
      <div
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(#2665DF 1.5px, transparent 1.5px)',
          backgroundSize: '24px 24px',
        }}
      />

      <div className="w-full max-w-md relative z-10 space-y-8">
        {/* Header Branding */}
        <div className="text-center flex flex-col items-center">
          <button
            onClick={() => onNavigateTab('home')}
            className="inline-block hover:opacity-90 transition-opacity mb-4 cursor-pointer"
            aria-label="Back to home"
          >
            <SignSpellLogo size="lg" darkMode={true} />
          </button>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">
            {mode === 'login' ? 'Welcome Back' : 'Create Your Account'}
          </h2>
          <p className="text-xs sm:text-sm text-gray-400 mt-2 max-w-sm">
            {mode === 'login'
              ? 'Sign in to access your ASL practice history, accuracy metrics, and saved tracks.'
              : 'Join SignSpell to begin learning American Sign Language with real-time interpretation.'}
          </p>
        </div>

        {/* Tab switcher: Sign In vs Create Account */}
        <div className="bg-[#091019] p-1.5 rounded-2xl border border-gray-800 flex text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setSimulatedFeedback(null);
            }}
            className={`flex-1 py-2.5 rounded-xl transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-[#2665DF] text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setSimulatedFeedback(null);
            }}
            className={`flex-1 py-2.5 rounded-xl transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-[#2665DF] text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Register
          </button>
        </div>

        {/* Feedback Alert if user attempts form submission */}
        {simulatedFeedback && (
          <div className="p-4 rounded-xl bg-blue-950/80 border border-[#2665DF] text-blue-200 text-xs flex items-start gap-2.5 animate-fade-in">
            <Sparkles className="w-4 h-4 text-[#2665DF] shrink-0 mt-0.5" />
            <p>{simulatedFeedback}</p>
          </div>
        )}

        {/* Main Auth Card */}
        <div
          className="rounded-3xl p-6 sm:p-8 border border-gray-800 shadow-2xl relative"
          style={{ backgroundColor: '#101926' }}
        >
          {mode === 'login' ? (
            /* Login Form */
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="learner@signspell.org"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                </div>
              </div>

              {/* Password field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => alert('Password reset placeholder (functionality not yet added).')}
                    className="text-xs text-[#2665DF] hover:underline font-semibold"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-3 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember me checkbox */}
              <div className="flex items-center gap-2">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-700 bg-[#091019] text-[#2665DF] focus:ring-[#2665DF] focus:ring-offset-0 cursor-pointer"
                />
                <label htmlFor="remember-me" className="text-xs text-gray-400 select-none cursor-pointer">
                  Remember my session on this browser
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer"
                style={{ backgroundColor: '#2665DF' }}
              >
                <span>Sign In to SignSpell</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            /* Registration Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="Alex Morgan"
                    value={registerName}
                    onChange={(e) => setRegisterName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="learner@signspell.org"
                    value={registerEmail}
                    onChange={(e) => setRegisterEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                  Create Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="At least 8 characters"
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div className="space-y-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-300">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    placeholder="Repeat password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-[#091019] border border-gray-700 text-white placeholder-gray-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#2665DF] focus:ring-1 focus:ring-[#2665DF] transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Terms checkbox */}
              <div className="flex items-start gap-2 pt-1">
                <input
                  id="agree-terms"
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded border-gray-700 bg-[#091019] text-[#2665DF] focus:ring-[#2665DF] focus:ring-offset-0 cursor-pointer"
                />
                <label htmlFor="agree-terms" className="text-xs text-gray-400 leading-relaxed select-none cursor-pointer">
                  I agree to the <span className="text-[#2665DF] hover:underline">Terms of Service</span> and{' '}
                  <span className="text-[#2665DF] hover:underline">Privacy Policy</span>.
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white transition-all shadow-lg hover:shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer mt-2"
                style={{ backgroundColor: '#2665DF' }}
              >
                <span>Create Free Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Divider */}
          <div className="relative my-6 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-800" />
            </div>
            <span className="relative px-3 text-[11px] uppercase tracking-wider text-gray-500 bg-[#101926]">
              Quick Access
            </span>
          </div>

          {/* Direct Launch Guest / Studio Button */}
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => onNavigateTab('practice')}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-gray-300 bg-[#091019] hover:bg-[#111C2B] border border-gray-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Continue as Guest in Studio</span>
            </button>
          </div>
        </div>

        {/* Security & Accessibility Note */}
        <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>Encrypted connection • High-contrast WCAG AA interface</span>
        </div>
      </div>
    </div>
  );
};
