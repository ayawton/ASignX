import React from 'react';
import { ActiveTab } from '../types';
import { SignSpellLogo } from './SignSpellLogo';
import { Twitter, Instagram, Youtube, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
  darkMode: boolean;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, darkMode }) => {
  return (
    <footer
      id="signspell-footer"
      className="border-t border-gray-800 transition-colors py-12 text-gray-400"
      style={{ backgroundColor: '#09101A' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Navigation directory */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-xs">
          <div className="space-y-3 sm:col-span-2">
            <SignSpellLogo size="sm" darkMode={true} />
            <p className="text-gray-400 max-w-sm text-xs leading-relaxed mt-2">
              Real-time ASL interpretation and interactive fingerspelling hub powered by computer vision.
              Break the barrier. Let every sign be heard.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Explore Hub</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveTab('home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Landing Page
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('practice')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Interactive Studio
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('dictionary')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  ASL Sign Dictionary (46 Signs)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('quiz')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Knowledge Check Quiz
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('login')}
                  className="hover:text-white text-[#2665DF] transition-colors cursor-pointer font-bold"
                >
                  Sign In / Register
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Color System</h4>
            <ul className="space-y-1.5 text-gray-400">
              <li className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#2665DF]" />
                <span>Primary: #2665DF</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#101926] border border-gray-700" />
                <span>Dark Canvas: #101926</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#F7F8FA] border border-gray-400" />
                <span>Light Canvas: #F7F8FA</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Exact Footer Bar from fss.png */}
        <div className="pt-8 border-t border-gray-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="text-gray-400 font-medium">
            © 2025 SignSpell. All rights reserved.
          </div>

          <div className="flex items-center gap-5 text-gray-400">
            <a
              href="#twitter"
              onClick={(e) => e.preventDefault()}
              aria-label="Twitter / X"
              className="hover:text-white transition-colors"
            >
              <Twitter className="w-4 h-4" />
            </a>
            <a
              href="#instagram"
              onClick={(e) => e.preventDefault()}
              aria-label="Instagram"
              className="hover:text-white transition-colors"
            >
              <Instagram className="w-4 h-4" />
            </a>
            <a
              href="#youtube"
              onClick={(e) => e.preventDefault()}
              aria-label="YouTube"
              className="hover:text-white transition-colors"
            >
              <Youtube className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
