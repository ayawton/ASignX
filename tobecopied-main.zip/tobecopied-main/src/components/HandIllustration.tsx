import React from 'react';

interface HandIllustrationProps {
  type: string;
  symbol: string;
  className?: string;
  size?: number;
  highlightColor?: string;
}

export const HandIllustration: React.FC<HandIllustrationProps> = ({
  type,
  symbol,
  className = '',
  size = 110,
  highlightColor = '#2665DF',
}) => {
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-[#E8F0FF] p-3 transition-transform duration-200 hover:scale-105 ${className}`}
      style={{ width: size, height: size }}
      role="img"
      aria-label={`Hand shape diagram for ASL ${symbol}`}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-full select-none"
      >
        {/* Palm / Hand base silhouette */}
        <rect x="24" y="42" width="52" height="42" rx="14" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
        
        {/* Wrist base */}
        <path d="M36 84 L36 94 L64 94 L64 84" stroke="#2665DF" strokeWidth="2.5" strokeLinecap="round" fill="#FFFFFF" />

        {/* Dynamic finger representations based on sign type */}
        {type === 'fist-thumb-side' || symbol === 'A' ? (
          // Fist with thumb straight on side
          <g>
            <rect x="28" y="32" width="10" height="20" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="39" y="30" width="10" height="22" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="50" y="32" width="10" height="20" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="61" y="36" width="9" height="16" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            {/* Thumb resting vertical along side of index */}
            <path d="M22 62 C20 48, 22 36, 26 30 C30 30, 32 34, 30 52" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" strokeLinecap="round" />
            {/* Thumb nail detail */}
            <circle cx="26" cy="34" r="2.5" fill="#FFFFFF" />
          </g>
        ) : type === 'flat-four-thumb-across' || symbol === 'B' ? (
          // Flat four fingers up, thumb folded across palm
          <g>
            <rect x="27" y="12" width="10" height="38" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="38" y="8" width="10" height="42" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="49" y="10" width="10" height="40" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="60" y="18" width="9" height="32" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            {/* Thumb tucked across */}
            <path d="M24 58 Q45 60 55 58 Q55 68 40 68 Z" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
          </g>
        ) : type === 'curved-c' || symbol === 'C' ? (
          // Curved C arc
          <g>
            <path d="M68 24 C45 15, 20 30, 22 55 C24 75, 48 84, 68 76" stroke="#2665DF" strokeWidth="8" strokeLinecap="round" fill="none" />
            <circle cx="68" cy="24" r="4.5" fill={highlightColor} />
            <circle cx="68" cy="76" r="4.5" fill={highlightColor} />
          </g>
        ) : type === 'index-up-circle-base' || symbol === 'D' ? (
          // Index straight up, others form circle with thumb
          <g>
            <rect x="34" y="10" width="11" height="40" rx="5.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
            <ellipse cx="50" cy="56" rx="16" ry="12" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <circle cx="50" cy="56" r="6" fill="#E8F0FF" />
          </g>
        ) : type === 'l-shape' || symbol === 'L' ? (
          // L-shape: index up, thumb 90 deg out
          <g>
            <rect x="34" y="10" width="11" height="42" rx="5.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
            <rect x="46" y="34" width="10" height="18" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="57" y="36" width="9" height="16" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            {/* Horizontal thumb */}
            <path d="M12 56 L36 56 L36 68 L12 68 Z" rx="5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
          </g>
        ) : type === 'peace-v' || symbol === 'V' || symbol === '2' ? (
          // V peace sign
          <g>
            <path d="M34 12 L44 48 L32 48 Z" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" strokeLinejoin="round" />
            <path d="M64 12 L54 48 L66 48 Z" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" strokeLinejoin="round" />
            <circle cx="34" cy="14" r="5" fill={highlightColor} />
            <circle cx="64" cy="14" r="5" fill={highlightColor} />
            <rect x="36" y="44" width="28" height="24" rx="6" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
          </g>
        ) : type === 'pinky-up' || symbol === 'I' ? (
          // Pinky finger straight up
          <g>
            <rect x="30" y="34" width="10" height="18" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="41" y="32" width="10" height="20" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="52" y="34" width="10" height="18" rx="5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            {/* Pinky up */}
            <rect x="63" y="14" width="9" height="38" rx="4.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
          </g>
        ) : type === 'ok-three-up' || symbol === 'F' ? (
          // OK ring with 3 fingers up
          <g>
            <circle cx="34" cy="50" r="10" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="46" y="10" width="9" height="38" rx="4.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
            <rect x="56" y="12" width="9" height="36" rx="4.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
            <rect x="66" y="18" width="8" height="30" rx="4" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
          </g>
        ) : type === 'shaka-y' || symbol === 'Y' ? (
          // Y shape: thumb and pinky out
          <g>
            <path d="M12 50 L30 56 L26 66 L10 58 Z" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
            <rect x="68" y="24" width="9" height="34" rx="4.5" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" transform="rotate(25 68 24)" />
            <rect x="34" y="38" width="30" height="22" rx="6" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
          </g>
        ) : (
          // Default stylized clean hand glyph with prominent symbol letter
          <g>
            <rect x="28" y="24" width="9" height="26" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="39" y="18" width="9" height="32" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="50" y="20" width="9" height="30" rx="4.5" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <rect x="61" y="28" width="8" height="22" rx="4" fill="#FFFFFF" stroke="#2665DF" strokeWidth="2.5" />
            <ellipse cx="28" cy="58" rx="8" ry="12" fill={highlightColor} stroke="#1F56C5" strokeWidth="2.5" />
          </g>
        )}

        {/* Small corner badge indicating letter/symbol */}
        <circle cx="80" cy="80" r="14" fill="#2665DF" />
        <text
          x="80"
          y="85"
          textAnchor="middle"
          fill="#FFFFFF"
          fontSize="14"
          fontWeight="bold"
          fontFamily="system-ui"
        >
          {symbol.length > 2 ? symbol.charAt(0) : symbol}
        </text>
      </svg>
    </div>
  );
};
