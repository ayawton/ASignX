import React from 'react';
import { ActiveTab, UserProgress } from '../types';
import { SignSpellLogo } from './SignSpellLogo';
import { Sparkles, BookOpen, Camera, Search, HelpCircle, Sun, Moon, Flame, Eye } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  highContrast: boolean;
  setHighContrast: (val: boolean | ((prev: boolean) => boolean)) => void;
  userProgress: UserProgress;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  darkMode,
  setDarkMode,
  highContrast,
  setHighContrast,
  userProgress,
}) => {
  const handleNavClick = (tab: ActiveTab, anchorId?: string) => {
    setActiveTab(tab);
    if (anchorId) {
      setTimeout(() => {
        const el = document.getElementById(anchorId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    }
  };

  const isNavDark = darkMode || activeTab === 'home' || activeTab === 'login' || activeTab === 'register';

  return (
    <header
      id="signspell-header"
      className={`sticky top-0 z-50 transition-colors duration-200 border-b ${
        isNavDark
          ? 'bg-[#0D1522] border-gray-800 text-[#FFFFFF]'
          : 'bg-[#FFFFFF] border-gray-200 text-[#111827]'
      } ${highContrast ? 'border-b-2 border-black dark:border-white' : ''}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo from fss2.png */}
          <button
            id="brand-logo-btn"
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2 group text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2665DF] rounded-lg p-1 cursor-pointer"
            aria-label="SignSpell Home"
          >
            <SignSpellLogo size="md" darkMode={isNavDark} />
          </button>

          {/* Desktop Navigation: Exact tabs from fss.png (Home, About, How It Works) + App Features */}
          <nav className="hidden md:flex items-center gap-8" aria-label="Main Navigation">
            <button
              id="nav-home-tab"
              onClick={() => handleNavClick('home')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer relative ${
                activeTab === 'home'
                  ? 'text-[#2665DF]'
                  : isNavDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <span>Home</span>
              {activeTab === 'home' && (
                <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#2665DF] rounded-full" />
              )}
            </button>

            <button
              id="nav-about-tab"
              onClick={() => handleNavClick('home', 'about-section')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer ${
                isNavDark ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              About
            </button>

            <button
              id="nav-howitworks-tab"
              onClick={() => handleNavClick('home', 'how-it-works-section')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer ${
                isNavDark ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              How It Works
            </button>

            {/* Hub Tools: Studio, Dictionary, Quiz */}
            <div className="h-4 w-px bg-gray-700/60 dark:bg-gray-700 mx-1" />

            <button
              id="nav-practice-tab"
              onClick={() => setActiveTab('practice')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer relative ${
                activeTab === 'practice'
                  ? 'text-[#2665DF]'
                  : isNavDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <span>Studio</span>
              {activeTab === 'practice' && (
                <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#2665DF] rounded-full" />
              )}
            </button>

            <button
              id="nav-dictionary-tab"
              onClick={() => setActiveTab('dictionary')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer relative ${
                activeTab === 'dictionary'
                  ? 'text-[#2665DF]'
                  : isNavDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <span>Dictionary</span>
              {activeTab === 'dictionary' && (
                <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#2665DF] rounded-full" />
              )}
            </button>

            <button
              id="nav-quiz-tab"
              onClick={() => setActiveTab('quiz')}
              className={`py-2 text-sm font-semibold transition-all cursor-pointer relative ${
                activeTab === 'quiz'
                  ? 'text-[#2665DF]'
                  : isNavDark
                  ? 'text-gray-300 hover:text-white'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <span>Quiz</span>
              {activeTab === 'quiz' && (
                <span className="absolute bottom-0 inset-x-0 h-0.5 bg-[#2665DF] rounded-full" />
              )}
            </button>
          </nav>

          {/* Right Action Items: Streak, Accessibility, Theme */}
          <div className="flex items-center gap-3">
            {/* Streak Pill */}
            <div
              id="streak-badge"
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border transition-colors ${
                isNavDark
                  ? 'bg-[#101926] border-gray-700 text-blue-300'
                  : 'bg-[#E8F0FF] border-[#2665DF]/20 text-[#2665DF]'
              }`}
              title={`${userProgress.streakDays} Day Practice Streak`}
            >
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>{userProgress.streakDays}d Streak</span>
            </div>

            {/* High Contrast Mode Toggle */}
            <button
              id="toggle-contrast-btn"
              onClick={() => setHighContrast((prev) => !prev)}
              aria-label={highContrast ? 'Disable high contrast mode' : 'Enable high contrast mode'}
              title={highContrast ? 'High Contrast Mode: Active' : 'Toggle High Contrast Mode'}
              className={`p-2 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                highContrast
                  ? 'bg-[#2665DF] text-[#FFFFFF] border-[#2665DF]'
                  : isNavDark
                  ? 'bg-[#101926] border-gray-700 text-gray-300 hover:text-[#FFFFFF]'
                  : 'bg-[#FFFFFF] border-gray-200 text-gray-700 hover:bg-[#F7F8FA]'
              }`}
            >
              <Eye className="w-4 h-4" />
            </button>

            {/* Theme Toggle */}
            <button
              id="toggle-theme-btn"
              onClick={() => setDarkMode((prev) => !prev)}
              aria-label={darkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
              title={darkMode ? 'Palette: Dark Background' : 'Palette: Light Background'}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                isNavDark
                  ? 'bg-[#101926] border-gray-700 text-amber-300 hover:bg-[#1f2d42]'
                  : 'bg-[#FFFFFF] border-gray-200 text-[#111827] hover:bg-[#F7F8FA]'
              }`}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Sign In button */}
            <button
              id="header-login-btn"
              onClick={() => setActiveTab('login')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'login' || activeTab === 'register'
                  ? 'bg-[#2665DF] text-white shadow-sm'
                  : isNavDark
                  ? 'text-gray-300 hover:text-white hover:bg-[#101926] border border-gray-700'
                  : 'text-gray-700 hover:text-[#2665DF] hover:bg-[#E8F0FF] border border-gray-200'
              }`}
            >
              Sign In
            </button>

            {/* Start Interpreting CTA in header */}
            <button
              onClick={() => setActiveTab('practice')}
              className="hidden lg:inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-[#2665DF] hover:bg-[#1F56C5] shadow-sm transition-colors cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Studio</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden overflow-x-auto py-2.5 gap-4 border-t border-gray-800 scrollbar-none text-xs font-semibold">
          <button
            onClick={() => handleNavClick('home')}
            className={`py-1 whitespace-nowrap ${
              activeTab === 'home' ? 'text-[#2665DF] border-b-2 border-[#2665DF]' : 'text-gray-400'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('home', 'about-section')}
            className="py-1 whitespace-nowrap text-gray-400"
          >
            About
          </button>
          <button
            onClick={() => handleNavClick('home', 'how-it-works-section')}
            className="py-1 whitespace-nowrap text-gray-400"
          >
            How It Works
          </button>
          <button
            onClick={() => setActiveTab('practice')}
            className={`py-1 whitespace-nowrap ${
              activeTab === 'practice' ? 'text-[#2665DF] border-b-2 border-[#2665DF]' : 'text-gray-400'
            }`}
          >
            Studio
          </button>
          <button
            onClick={() => setActiveTab('dictionary')}
            className={`py-1 whitespace-nowrap ${
              activeTab === 'dictionary' ? 'text-[#2665DF] border-b-2 border-[#2665DF]' : 'text-gray-400'
            }`}
          >
            Dictionary
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`py-1 whitespace-nowrap ${
              activeTab === 'quiz' ? 'text-[#2665DF] border-b-2 border-[#2665DF]' : 'text-gray-400'
            }`}
          >
            Quiz
          </button>
          <button
            onClick={() => setActiveTab('login')}
            className={`py-1 whitespace-nowrap ${
              activeTab === 'login' || activeTab === 'register'
                ? 'text-[#2665DF] border-b-2 border-[#2665DF]'
                : 'text-gray-400'
            }`}
          >
            Sign In
          </button>
        </div>
      </div>
    </header>
  );
};
