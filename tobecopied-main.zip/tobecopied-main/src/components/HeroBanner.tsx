import React from 'react';
import { UserProgress, ActiveTab } from '../types';
import { Camera, BookOpen, Award, ArrowRight, CheckCircle2, Zap } from 'lucide-react';

interface HeroBannerProps {
  userProgress: UserProgress;
  setActiveTab: (tab: ActiveTab) => void;
  onSelectSignForPractice: (signId: string) => void;
  darkMode: boolean;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  userProgress,
  setActiveTab,
  onSelectSignForPractice,
  darkMode,
}) => {
  const percentComplete = Math.round((userProgress.signsLearned / userProgress.totalSigns) * 100);

  return (
    <section
      id="hero-banner-section"
      className={`relative overflow-hidden rounded-3xl border transition-colors p-6 sm:p-8 lg:p-10 mb-8 ${
        darkMode
          ? 'bg-[#101926] border-[#1f2d42] text-[#FFFFFF]'
          : 'bg-[#FFFFFF] border-gray-200 text-[#111827] shadow-sm'
      }`}
    >
      {/* Subtle brand blue accent background glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-[#E8F0FF] dark:bg-[#2665DF]/10 blur-3xl pointer-events-none" />

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Hero Content */}
        <div className="lg:col-span-7 space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E8F0FF] text-[#2665DF] text-xs font-bold tracking-wide border border-[#2665DF]/20">
            <Zap className="w-3.5 h-3.5 fill-[#2665DF]" />
            <span>Interactive ASL Learning Hub</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-[1.15]">
            Master American Sign Language with{' '}
            <span className="text-[#2665DF]">Visual Confidence</span>
          </h1>

          <p className={`text-base sm:text-lg max-w-2xl leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Explore standard ASL fingerspelling, numbers, and core vocabulary. Prepare for live hand
            posture feedback in the upcoming AI Practice Studio shell.
          </p>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="hero-practice-btn"
              onClick={() => {
                setActiveTab('practice');
                onSelectSignForPractice('asl-a');
              }}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl font-bold text-sm text-[#FFFFFF] bg-[#2665DF] hover:bg-[#1F56C5] active:bg-[#1A4AA8] shadow-md shadow-blue-600/20 transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4" />
              <span>Launch Practice Studio</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-browse-dictionary-btn"
              onClick={() => setActiveTab('dictionary')}
              className={`inline-flex items-center gap-2 px-5 py-3.5 rounded-xl font-bold text-sm border transition-all cursor-pointer ${
                darkMode
                  ? 'bg-[#091019] border-[#1f2d42] text-[#FFFFFF] hover:bg-[#101926]'
                  : 'bg-[#F7F8FA] border-gray-300 text-[#111827] hover:bg-[#E8F0FF] hover:border-[#2665DF]/40 hover:text-[#2665DF]'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Browse 46 ASL Signs</span>
            </button>
          </div>
        </div>

        {/* Right Stats & Progress Card */}
        <div className="lg:col-span-5">
          <div
            className={`rounded-2xl p-6 border transition-colors ${
              darkMode
                ? 'bg-[#091019] border-[#1f2d42]'
                : 'bg-[#F7F8FA] border-gray-200'
            }`}
          >
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div>
                <span className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400">
                  Current Level
                </span>
                <h3 className="text-lg font-bold text-[#2665DF]">
                  {userProgress.currentLevel}
                </h3>
              </div>
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-[#E8F0FF] text-[#2665DF]">
                <Award className="w-5 h-5" />
              </div>
            </div>

            {/* Progress Bar */}
            <div className="py-4 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className={darkMode ? 'text-gray-300' : 'text-gray-600'}>Curriculum Mastery</span>
                <span className="text-[#2665DF] font-bold">{percentComplete}% Complete</span>
              </div>
              <div className="w-full h-3 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-[#2665DF] transition-all duration-500"
                  style={{ width: `${percentComplete}%` }}
                />
              </div>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className={`p-3 rounded-xl text-center border ${
                darkMode ? 'bg-[#101926] border-[#1f2d42]' : 'bg-[#FFFFFF] border-gray-200'
              }`}>
                <div className="text-xl font-extrabold text-[#2665DF]">{userProgress.signsLearned}</div>
                <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Mastered</div>
              </div>

              <div className={`p-3 rounded-xl text-center border ${
                darkMode ? 'bg-[#101926] border-[#1f2d42]' : 'bg-[#FFFFFF] border-gray-200'
              }`}>
                <div className="text-xl font-extrabold text-[#2665DF]">{userProgress.practiceMinutes}m</div>
                <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Practiced</div>
              </div>

              <div className={`p-3 rounded-xl text-center border ${
                darkMode ? 'bg-[#101926] border-[#1f2d42]' : 'bg-[#FFFFFF] border-gray-200'
              }`}>
                <div className="text-xl font-extrabold text-[#2665DF]">{userProgress.accuracyRate}%</div>
                <div className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Accuracy</div>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <CheckCircle2 className="w-4 h-4 text-[#2665DF]" />
              <span>Next goal: Complete Letters N through Z to earn the Manualist badge.</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
