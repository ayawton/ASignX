import React from 'react';
import { ActiveTab, ASLSign } from '../types';
import { Clock, Brain, Languages, ArrowRight, Play, CheckCircle2, Shield, Eye } from 'lucide-react';
import { ASL_SIGNS } from '../data/aslData';
import heroPersonImage from '../assets/images/person_signing_hand_1788622094548.jpg';

interface LandingPageProps {
  onStartInterpreting: () => void;
  onExploreDictionary: () => void;
  onStartQuiz: () => void;
  darkMode: boolean;
  onNavigateTab: (tab: ActiveTab) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStartInterpreting,
  onExploreDictionary,
  onStartQuiz,
  darkMode,
  onNavigateTab,
}) => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="signspell-landing-page" className="w-full">
      {/* Hero Section (Matching fss.png exact layout and colors) */}
      <section
        id="hero-section"
        className="w-full px-6 sm:px-12 lg:px-20 py-16 sm:py-24"
        style={{ backgroundColor: '#0D1522' }}
      >
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Headline, Copy & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-black tracking-tight text-white uppercase leading-[1.12]">
              BREAK THE BARRIER.
              <br />
              LET EVERY SIGN BE HEARD.
            </h1>

            <p className="text-gray-300 text-base sm:text-lg leading-relaxed max-w-xl mt-6">
              Real-time ASL interpretation powered by AI. Sign naturally. Our system recognizes
              your signs and transforms them into meaningful sentences.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 mt-8">
              <button
                id="hero-start-interpreting-btn"
                onClick={onStartInterpreting}
                className="px-7 py-3.5 rounded-lg font-semibold text-sm text-white transition-all shadow-lg hover:shadow-blue-600/30 active:scale-95 cursor-pointer"
                style={{ backgroundColor: '#2665DF' }}
              >
                Start Interpreting
              </button>

              <button
                id="hero-learn-more-btn"
                onClick={() => scrollToSection('how-it-works-section')}
                className="px-7 py-3.5 rounded-lg font-semibold text-sm text-white transition-all border border-gray-400/80 hover:bg-white/10 active:scale-95 cursor-pointer"
                style={{ backgroundColor: '#111C2B' }}
              >
                Learn More
              </button>
            </div>
          </div>

          {/* Right Column: Person Showing Hand in American Sign Language */}
          <div className="lg:col-span-5 flex justify-center w-full">
            <div
              id="hero-person-stage"
              className="w-full aspect-[4/3] sm:aspect-[16/12] max-w-lg rounded-3xl border border-gray-700/60 overflow-hidden shadow-2xl shadow-blue-950/40 bg-[#091019]"
            >
              <img
                src={heroPersonImage}
                alt="Person showing hand in American Sign Language gesture"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center select-none"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section (Exact 3 Cards from fss.png) */}
      <section
        id="features-section"
        className="w-full px-6 sm:px-12 lg:px-20 py-16 sm:py-24"
        style={{ backgroundColor: '#F7F8FA' }}
      >
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1: Real-Time Recognition */}
          <div
            id="feature-card-realtime"
            className="bg-white rounded-2xl p-8 sm:p-10 border border-gray-100 shadow-sm text-center flex flex-col items-center transition-all hover:shadow-md hover:-translate-y-0.5"
          >
            <div className="w-16 h-16 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center mb-6">
              <Clock className="w-8 h-8 text-[#2665DF]" />
            </div>
            <h3 className="font-bold text-lg text-[#111827] mb-2">Real-Time Recognition</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              Instantly detects and interprets ASL signs using advanced computer vision.
            </p>
          </div>

          {/* Card 2: AI-Powered Detection */}
          <div
            id="feature-card-detection"
            className="bg-white rounded-2xl p-8 sm:p-10 border border-gray-100 shadow-sm text-center flex flex-col items-center transition-all hover:shadow-md hover:-translate-y-0.5"
          >
            <div className="w-16 h-16 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center mb-6">
              <Brain className="w-8 h-8 text-[#2665DF]" />
            </div>
            <h3 className="font-bold text-lg text-[#111827] mb-2">AI-Powered Detection</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              Smart AI models trained to understand a wide range of signs and gestures.
            </p>
          </div>

          {/* Card 3: Language Processing */}
          <div
            id="feature-card-language"
            className="bg-white rounded-2xl p-8 sm:p-10 border border-gray-100 shadow-sm text-center flex flex-col items-center transition-all hover:shadow-md hover:-translate-y-0.5"
          >
            <div className="w-16 h-16 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center mb-6">
              <Languages className="w-8 h-8 text-[#2665DF]" />
            </div>
            <h3 className="font-bold text-lg text-[#111827] mb-2">Language Processing</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              Converts recognized signs into natural, grammatically correct sentences.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section (Linked by the Navbar & Learn More button) */}
      <section
        id="how-it-works-section"
        className="w-full px-6 sm:px-12 lg:px-20 py-20 border-t border-b border-gray-200"
        style={{ backgroundColor: '#FFFFFF' }}
      >
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-widest text-[#2665DF]">
              Workflow Architecture
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-[#111827] tracking-tight mt-2">
              How SignSpell Interprets Your Signs
            </h2>
            <p className="text-sm text-gray-500 mt-2">
              Designed from the ground up for instantaneous visual feedback with zero latency.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-[#F7F8FA] border border-gray-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#2665DF] text-white font-bold flex items-center justify-center text-sm">
                1
              </div>
              <h4 className="font-bold text-base text-[#111827]">Webcam Hand Tracking</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Your browser webcam streams video to the client. The system identifies palm orientation and isolates all 21 joint landmark coordinates.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F7F8FA] border border-gray-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#2665DF] text-white font-bold flex items-center justify-center text-sm">
                2
              </div>
              <h4 className="font-bold text-base text-[#111827]">Spatial Posture Analysis</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Algorithms compare finger curvature, thumb alignment, and wrist rotation against the standard ASL manual sign dataset.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F7F8FA] border border-gray-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#2665DF] text-white font-bold flex items-center justify-center text-sm">
                3
              </div>
              <h4 className="font-bold text-base text-[#111827]">Audio & Sentence Output</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Recognized gestures are decoded into text captions and read aloud via built-in speech synthesis for seamless two-way dialogue.
              </p>
            </div>
          </div>

          {/* Quick links banner to the other tools */}
          <div className="p-6 sm:p-8 rounded-3xl bg-[#0D1522] text-white flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-lg font-bold">Ready to practice your fingerspelling?</h3>
              <p className="text-xs text-gray-400 mt-1">
                Explore the 46 sign dictionary, test knowledge in the quiz arena, or launch the camera studio.
              </p>
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={onStartInterpreting}
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-[#2665DF] hover:bg-[#1F56C5] text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Launch Studio
              </button>
              <button
                onClick={onExploreDictionary}
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors border border-white/20 cursor-pointer"
              >
                Sign Dictionary
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section
        id="about-section"
        className="w-full px-6 sm:px-12 lg:px-20 py-20"
        style={{ backgroundColor: '#F7F8FA' }}
      >
        <div className="max-w-4xl mx-auto space-y-6 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-[#2665DF]">
            About SignSpell
          </span>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight">
            Bridging Worlds Through Accessible Technology
          </h2>
          <p className="text-sm text-gray-600 leading-relaxed">
            American Sign Language is a rich, expressive natural language used by millions of Deaf
            and hard-of-hearing individuals. SignSpell was created to lower the barriers to entry,
            giving hearing learners an intuitive, real-time mirror to practice their manual dexterity,
            while pioneering bidirectional interpretation systems.
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <button
              onClick={onStartQuiz}
              className="px-6 py-3 rounded-xl bg-white border border-gray-300 font-bold text-xs text-[#111827] hover:bg-gray-50 transition-colors cursor-pointer"
            >
              Take Knowledge Quiz
            </button>
            <button
              onClick={() => onNavigateTab('register')}
              className="px-6 py-3 rounded-xl bg-[#2665DF] text-white font-bold text-xs hover:bg-[#1F56C5] transition-colors cursor-pointer shadow-sm"
            >
              Create Free Account
            </button>
            <button
              onClick={() => onNavigateTab('learn')}
              className="px-6 py-3 rounded-xl bg-white border border-gray-300 font-bold text-xs text-gray-700 hover:bg-[#E8F0FF] hover:text-[#2665DF] transition-colors cursor-pointer"
            >
              View Lessons Pathway
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
