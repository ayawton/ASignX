import React from 'react';
import { LessonTrack } from '../types';
import { BookOpen, Clock, CheckCircle2, ArrowRight, Play } from 'lucide-react';

interface LessonCardsProps {
  tracks: LessonTrack[];
  onStartTrack: (track: LessonTrack) => void;
  darkMode: boolean;
}

export const LessonCards: React.FC<LessonCardsProps> = ({
  tracks,
  onStartTrack,
  darkMode,
}) => {
  return (
    <div id="lesson-tracks-section" className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight">
            Curriculum Pathways
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
            Structured modules from basic manual alphabet to everyday conversational signs
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {tracks.map((track) => {
          const progressPercent = Math.round((track.completedCount / track.signCount) * 100);
          const isComplete = progressPercent === 100;

          return (
            <div
              key={track.id}
              className={`rounded-3xl border p-6 flex flex-col justify-between transition-all duration-200 ${
                darkMode
                  ? 'bg-[#101926] border-[#1f2d42] hover:border-[#2665DF] text-[#FFFFFF]'
                  : 'bg-[#FFFFFF] border-gray-200 hover:border-[#2665DF] hover:shadow-md text-[#111827]'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-[#E8F0FF] text-[#2665DF]">
                    {track.level}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{track.estimatedMinutes} mins</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-extrabold tracking-tight">
                    {track.title}
                  </h3>
                  <p className="text-xs text-gray-600 dark:text-gray-300 mt-1.5 leading-relaxed">
                    {track.subtitle}
                  </p>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-[11px] font-semibold text-gray-500 dark:text-gray-400">
                    <span>Progress</span>
                    <span>
                      {track.completedCount} / {track.signCount} signs ({progressPercent}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
                    <div
                      className="h-full bg-[#2665DF] rounded-full transition-all duration-300"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-6 mt-4 border-t border-gray-100 dark:border-gray-800">
                <button
                  onClick={() => onStartTrack(track)}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    isComplete
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'bg-[#2665DF] hover:bg-[#1F56C5] text-white shadow-sm'
                  }`}
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isComplete ? 'Review Pathway' : 'Continue Lesson'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
