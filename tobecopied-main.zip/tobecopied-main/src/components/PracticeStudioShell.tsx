import React, { useState, useRef, useEffect } from 'react';
import { ASLSign } from '../types';
import { HandIllustration } from './HandIllustration';
import {
  Camera,
  CameraOff,
  CheckCircle2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Info,
  Layers,
  RotateCcw,
  Sparkles,
  Volume2,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';

interface PracticeStudioShellProps {
  signs: ASLSign[];
  selectedSignId: string;
  onSelectSign: (signId: string) => void;
  darkMode: boolean;
}

export const PracticeStudioShell: React.FC<PracticeStudioShellProps> = ({
  signs,
  selectedSignId,
  onSelectSign,
  darkMode,
}) => {
  const currentSign = signs.find((s) => s.id === selectedSignId) || signs[0];
  const currentIndex = signs.findIndex((s) => s.id === currentSign.id);

  // Camera preview state
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Recognition simulation state (Demonstrating the shell's feedback states)
  const [simulationState, setSimulationState] = useState<'idle' | 'analyzing' | 'success' | 'retry'>('idle');
  const [simulatedConfidence, setSimulatedConfidence] = useState<number>(0);
  const [showSilhouette, setShowSilhouette] = useState<boolean>(true);
  const [guideSpeed, setGuideSpeed] = useState<'normal' | 'slow'>('normal');

  // Next / Previous navigation
  const handleNextSign = () => {
    const nextIdx = (currentIndex + 1) % signs.length;
    onSelectSign(signs[nextIdx].id);
    setSimulationState('idle');
  };

  const handlePrevSign = () => {
    const prevIdx = (currentIndex - 1 + signs.length) % signs.length;
    onSelectSign(signs[prevIdx].id);
    setSimulationState('idle');
  };

  // Camera start / stop logic
  const toggleCamera = async () => {
    if (cameraActive) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      setCameraActive(false);
      setCameraError(null);
    } else {
      setCameraError(null);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
          audio: false,
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraActive(true);
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : 'Camera access declined or unavailable';
        setCameraError(`${errorMessage}. You can continue in visual guide mode.`);
        setCameraActive(false);
      }
    }
  };

  // Clean up media stream on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Simulator runner to test how recognition feedback will render in the shell
  const triggerSimulation = (result: 'success' | 'retry') => {
    setSimulationState('analyzing');
    setSimulatedConfidence(0);

    setTimeout(() => {
      if (result === 'success') {
        setSimulationState('success');
        setSimulatedConfidence(96);
      } else {
        setSimulationState('retry');
        setSimulatedConfidence(48);
      }
    }, 900);
  };

  // Text-to-speech for accessible auditory feedback of handshape
  const speakTip = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(
        `${currentSign.name}. ${currentSign.handshapeDescription} Memory tip: ${currentSign.memoryTip}`
      );
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Category filter for the aside navigation
  const [activeCategory, setActiveCategory] = useState<string>(currentSign.category || 'alphabet');

  // Keep active category synced if currentSign changes
  useEffect(() => {
    if (currentSign.category && currentSign.category !== activeCategory) {
      setActiveCategory(currentSign.category);
    }
  }, [currentSign.category]);

  const categorySigns = signs.filter((s) => s.category === activeCategory);
  const completedCount = Math.max(1, currentIndex + 1);
  const moduleProgress = Math.min(100, Math.round((completedCount / (categorySigns.length || 1)) * 100));

  return (
    <div id="practice-studio-container" className="space-y-6">
      {/* Geometric Balance Workspace: Aside + Section Grid */}
      <div className="flex flex-col lg:flex-row rounded-3xl border border-gray-200 dark:border-[#1f2d42] overflow-hidden shadow-sm bg-[#F7F8FA] dark:bg-[#101926]">
        {/* Geometric Balance Aside Navigation Bar */}
        <aside
          className="w-full lg:w-72 shrink-0 flex flex-col border-b lg:border-b-0 lg:border-r border-gray-200 dark:border-gray-800"
          style={{ backgroundColor: '#101926' }}
        >
          {/* Aside Header: Current Module info */}
          <div className="p-6">
            <h3 className="text-xs font-bold uppercase tracking-widest mb-3 text-[#2665DF]">
              Current Module
            </h3>
            <div className="flex items-center justify-between">
              <h2 className="text-white text-lg font-semibold leading-tight capitalize">
                ASL {activeCategory === 'alphabet' ? 'Alphabet: Section 1' : activeCategory}
              </h2>
            </div>

            {/* Category switcher tabs */}
            <div className="grid grid-cols-3 gap-1 mt-3 bg-gray-900/60 p-1 rounded-xl text-[10px] font-bold">
              <button
                onClick={() => setActiveCategory('alphabet')}
                className={`py-1 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'alphabet' ? 'bg-[#2665DF] text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                Letters
              </button>
              <button
                onClick={() => setActiveCategory('numbers')}
                className={`py-1 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'numbers' ? 'bg-[#2665DF] text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                Numbers
              </button>
              <button
                onClick={() => setActiveCategory('greetings')}
                className={`py-1 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'greetings' || activeCategory === 'essentials' ? 'bg-[#2665DF] text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                Words
              </button>
            </div>

            {/* Module Progress Bar */}
            <div className="mt-4 h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{ width: `${moduleProgress}%`, backgroundColor: '#2665DF' }}
              />
            </div>
            <p className="text-xs mt-2 text-gray-400 font-medium">{moduleProgress}% Complete</p>
          </div>

          {/* Letter Navigation List */}
          <nav className="flex-1 overflow-y-auto px-3 max-h-[380px] lg:max-h-[440px] space-y-1">
            {categorySigns.map((sign, index) => {
              const isActive = sign.id === currentSign.id;
              const isPast = index < currentIndex && sign.category === currentSign.category;

              if (isActive) {
                return (
                  <button
                    key={sign.id}
                    onClick={() => {
                      onSelectSign(sign.id);
                      setSimulationState('idle');
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-blue-500/30 text-white transition-all text-left cursor-pointer"
                    style={{ backgroundColor: '#1F56C5' }}
                  >
                    <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center text-xs font-bold text-blue-600 shrink-0">
                      {sign.symbol.length <= 2 ? sign.symbol : sign.name.charAt(0)}
                    </div>
                    <span className="flex-1 font-medium text-sm truncate">{sign.name}</span>
                    <span className="animate-pulse text-xs">●</span>
                  </button>
                );
              }

              if (isPast) {
                return (
                  <button
                    key={sign.id}
                    onClick={() => {
                      onSelectSign(sign.id);
                      setSimulationState('idle');
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg bg-gray-800/50 hover:bg-gray-800/80 text-white transition-colors text-left cursor-pointer"
                  >
                    <div className="w-6 h-6 rounded-full border-2 border-blue-500 flex items-center justify-center text-xs font-bold shrink-0 text-blue-400">
                      {sign.symbol.length <= 2 ? sign.symbol : sign.name.charAt(0)}
                    </div>
                    <span className="flex-1 font-medium text-sm truncate">{sign.name}</span>
                    <span className="text-green-400 font-bold text-xs">✓</span>
                  </button>
                );
              }

              return (
                <button
                  key={sign.id}
                  onClick={() => {
                    onSelectSign(sign.id);
                    setSimulationState('idle');
                  }}
                  className="w-full flex items-center gap-3 p-3 rounded-lg text-gray-400 hover:bg-gray-800/30 hover:text-gray-200 transition-colors text-left cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-full border border-gray-600 flex items-center justify-center text-xs shrink-0">
                    {sign.symbol.length <= 2 ? sign.symbol : sign.name.charAt(0)}
                  </div>
                  <span className="flex-1 font-medium text-sm truncate">{sign.name}</span>
                </button>
              );
            })}
          </nav>

          {/* Aside Footer */}
          <div className="p-6 border-t border-gray-800 mt-auto">
            <button
              onClick={() => triggerSimulation('retry')}
              className="w-full py-3 rounded-xl font-bold text-sm transition-all text-white hover:bg-[#1F56C5] shadow-sm cursor-pointer"
              style={{ backgroundColor: '#2665DF' }}
            >
              Review Mistakes
            </button>
          </div>
        </aside>

        {/* Main Practice Section */}
        <section className="flex-1 flex flex-col p-6 sm:p-8 bg-[#F7F8FA] dark:bg-[#101926] min-w-0">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center shrink-0 shadow-xs">
                <Camera className="w-7 h-7 text-[#2665DF]" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#2665DF]">
                  Active Sign Recognition Studio
                </span>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight" style={{ color: darkMode ? '#FFFFFF' : '#111827' }}>
                  Practice: {currentSign.name}
                </h1>
                <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">
                  {currentSign.handshapeDescription} • {currentSign.palmOrientation}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                id="practice-skip-btn"
                onClick={handleNextSign}
                className="px-4 py-2.5 rounded-xl bg-white dark:bg-[#091019] border border-gray-200 dark:border-gray-700 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-[#111827] dark:text-white cursor-pointer"
              >
                Skip
              </button>
              <button
                id="practice-hint-btn"
                onClick={speakTip}
                className="px-4 py-2.5 rounded-xl bg-white dark:bg-[#091019] border border-gray-200 dark:border-gray-700 font-bold text-xs hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-[#111827] dark:text-white flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-[#2665DF]" />
                <span>Show Hint</span>
              </button>
            </div>
          </div>

          {/* Two-Column Geometric Balance Grid */}
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
            {/* Left Card: Target Reference */}
            <div className="bg-white dark:bg-[#091019] rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden flex flex-col">
              <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center bg-gray-50 dark:bg-[#101926]">
                <span className="text-xs font-bold uppercase text-gray-400 tracking-wider">
                  Target Reference
                </span>
                <span className="text-xs font-medium px-2 py-1 bg-white dark:bg-[#091019] rounded border border-gray-200 dark:border-gray-700 text-[#111827] dark:text-white">
                  ASL Standard
                </span>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center bg-white dark:bg-[#091019] p-6 sm:p-10">
                <div className="relative w-full flex-1 border-4 border-dashed border-blue-100 dark:border-blue-900/30 rounded-2xl flex flex-col items-center justify-center p-6 bg-blue-50/20 dark:bg-blue-950/10 min-h-[220px]">
                  <div className="text-center flex flex-col items-center justify-center">
                    <HandIllustration
                      type={currentSign.svgType}
                      symbol={currentSign.symbol}
                      size={150}
                      className="drop-shadow-sm"
                    />
                    <p className="text-blue-500 dark:text-blue-400 font-medium text-xs mt-3">
                      Reference Handshape Display
                    </p>
                  </div>
                </div>

                {/* Micro specs */}
                <div className="w-full mt-5 space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-[#101926] border border-gray-100 dark:border-gray-800">
                    <span className="font-bold text-gray-500 dark:text-gray-400 uppercase text-[10px] tracking-wider">
                      Orientation
                    </span>
                    <span className="font-semibold text-[#2665DF]">{currentSign.palmOrientation}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#E8F0FF]/50 dark:bg-blue-950/20 border border-[#2665DF]/20 text-[11px] text-gray-700 dark:text-gray-300">
                    <strong>Tip:</strong> "{currentSign.memoryTip}"
                  </div>
                </div>
              </div>
            </div>

            {/* Right Card: Camera Viewport with Geometric Corners */}
            <div
              className="rounded-3xl shadow-2xl overflow-hidden flex flex-col relative min-h-[460px]"
              style={{ backgroundColor: '#091019' }}
            >
              {/* Active / Standby Indicator */}
              <div className="absolute top-4 left-4 z-10 flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 backdrop-blur-md border border-white/10">
                <div className={`w-2 h-2 rounded-full ${cameraActive ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`} />
                <span className="text-xs font-bold text-white tracking-widest uppercase">
                  {cameraActive ? 'Camera Active' : 'Camera Ready'}
                </span>
              </div>

              {/* Viewport Stage with Radial Dot Matrix & 4 Corner Geometric Brackets */}
              <div className="flex-1 flex items-center justify-center relative p-6">
                {/* Radial Dot Pattern */}
                <div
                  className="absolute inset-0 opacity-20 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(#2665DF 1px, transparent 1px)',
                    backgroundSize: '20px 20px',
                  }}
                />

                {/* Video Element */}
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`absolute inset-0 w-full h-full object-cover transform -scale-x-100 ${
                    cameraActive ? 'block' : 'hidden'
                  }`}
                />

                {/* Geometric Bracket Frame Box */}
                <div className="w-64 h-80 sm:w-72 sm:h-84 border-2 border-blue-500/50 rounded-3xl relative flex flex-col items-center justify-center">
                  {/* The 4 Geometric Balance Corner Brackets */}
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-blue-500 -mt-1 -ml-1 rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-blue-500 -mt-1 -mr-1 rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-blue-500 -mb-1 -ml-1 rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-blue-500 -mb-1 -mr-1 rounded-br-lg" />

                  {/* Silhouette overlay wireframe */}
                  {showSilhouette && !cameraActive && (
                    <div className="w-full h-full flex flex-col items-center justify-center text-center p-6 select-none">
                      <div className="text-6xl mb-2 opacity-30 grayscale">✋</div>
                      <p className="text-gray-400 text-sm font-medium">Position your hand inside the frame</p>
                      <button
                        onClick={toggleCamera}
                        className="mt-3 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#2665DF] text-white hover:bg-[#1F56C5] cursor-pointer"
                      >
                        Start Camera
                      </button>
                    </div>
                  )}

                  {showSilhouette && cameraActive && (
                    <div className="pointer-events-none flex flex-col items-center">
                      <div className="px-3 py-1 rounded-full bg-black/60 border border-blue-500/40 text-[11px] font-bold text-blue-200">
                        Align Hand Center
                      </div>
                    </div>
                  )}
                </div>

                {/* Status Feedback Toast */}
                {simulationState !== 'idle' && (
                  <div className="absolute top-16 inset-x-6 z-20 flex justify-center pointer-events-none">
                    {simulationState === 'analyzing' && (
                      <div className="flex items-center gap-2.5 px-4 py-2 rounded-xl bg-[#101926]/95 border border-[#2665DF] text-[#FFFFFF] shadow-lg backdrop-blur-md">
                        <div className="w-3.5 h-3.5 border-2 border-[#2665DF] border-t-transparent rounded-full animate-spin" />
                        <span className="text-xs font-bold">Scanning Hand Landmarks...</span>
                      </div>
                    )}
                    {simulationState === 'success' && (
                      <div className="flex items-center gap-2.5 px-4 py-2 rounded-xl bg-emerald-950/95 border border-emerald-500 text-emerald-100 shadow-xl backdrop-blur-md">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-xs font-bold">Sign Matched with {simulatedConfidence}% Accuracy</span>
                      </div>
                    )}
                    {simulationState === 'retry' && (
                      <div className="flex items-center gap-2.5 px-4 py-2 rounded-xl bg-amber-950/95 border border-amber-500 text-amber-100 shadow-xl backdrop-blur-md">
                        <AlertCircle className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-bold">Check Thumb Angle and Palm Rotation</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Status Bar from Geometric Balance */}
              <div className="p-6 bg-black/40 backdrop-blur-md flex items-center justify-between border-t border-white/10 mt-auto">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">
                    Status
                  </span>
                  <span className="text-white font-medium text-sm">
                    {simulationState === 'analyzing'
                      ? 'Analyzing landmark mesh...'
                      : simulationState === 'success'
                      ? 'Gesture recognized!'
                      : simulationState === 'retry'
                      ? 'Posture adjustment suggested'
                      : cameraActive
                      ? 'Live feed active'
                      : 'Waiting for gesture...'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => triggerSimulation('success')}
                    title="Simulate Match"
                    aria-label="Simulate Match"
                    className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </button>
                  <button
                    onClick={toggleCamera}
                    title={cameraActive ? 'Stop Camera' : 'Start Camera'}
                    aria-label={cameraActive ? 'Stop Camera' : 'Start Camera'}
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-white transition-colors cursor-pointer ${
                      cameraActive ? 'bg-red-600 hover:bg-red-700' : 'bg-white/10 hover:bg-white/20'
                    }`}
                  >
                    <Camera className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
