import React, { useState } from 'react';
import { QuizItem, QUIZ_QUESTIONS, ASL_SIGNS } from '../data/aslData';
import { HandIllustration } from './HandIllustration';
import { CheckCircle2, XCircle, RotateCcw, Award, ArrowRight, HelpCircle } from 'lucide-react';

interface QuizArenaProps {
  onSelectSignForPractice: (signId: string) => void;
  darkMode: boolean;
}

export const QuizArena: React.FC<QuizArenaProps> = ({
  onSelectSignForPractice,
  darkMode,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const question = QUIZ_QUESTIONS[currentIndex];
  const matchedSign = ASL_SIGNS.find((s) => s.id === question.signId);

  const handleSelect = (option: string) => {
    if (selectedOption !== null) return;
    setSelectedOption(option);
    if (option === question.correctAnswer) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      setIsFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScore(0);
    setIsFinished(false);
  };

  return (
    <div id="quiz-arena-container" className="max-w-3xl mx-auto space-y-6">
      {/* Header matching fss.png scheme */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-colors ${
          darkMode
            ? 'bg-[#101926] border-gray-800 text-[#FFFFFF]'
            : 'bg-[#FFFFFF] border-gray-200 text-[#111827] shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center shrink-0 shadow-xs">
              <HelpCircle className="w-7 h-7 text-[#2665DF]" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#2665DF]">
                ASL Knowledge Check
              </span>
              <h2 className="text-xl font-black tracking-tight">Handshape & Manual Rules</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                Identify finger positioning, spatial orientation, and movement
              </p>
            </div>
          </div>

          <span className="self-start sm:self-auto text-xs font-bold px-3.5 py-1.5 rounded-full bg-[#E8F0FF] text-[#2665DF] border border-[#2665DF]/20">
            Question {currentIndex + 1} of {QUIZ_QUESTIONS.length}
          </span>
        </div>
      </div>

      {!isFinished ? (
        <div
          className={`p-6 sm:p-8 rounded-3xl border transition-colors space-y-6 ${
            darkMode
              ? 'bg-[#101926] border-gray-800 text-[#FFFFFF]'
              : 'bg-[#FFFFFF] border-gray-200 text-[#111827] shadow-sm'
          }`}
        >
          {/* Question Text */}
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#2665DF] block mb-1.5">
              Question #{currentIndex + 1}
            </span>
            <h3 className="text-lg sm:text-xl font-black leading-snug">
              {question.questionText}
            </h3>
          </div>

          {/* Optional Illustration if available */}
          {matchedSign && (
            <div className="flex justify-center py-4 bg-[#F7F8FA] dark:bg-[#091019] rounded-2xl border border-gray-100 dark:border-gray-800">
              <HandIllustration
                type={matchedSign.svgType}
                symbol={matchedSign.symbol}
                size={120}
              />
            </div>
          )}

          {/* Options Grid */}
          <div className="space-y-3">
            {question.options.map((option, idx) => {
              const isSelected = selectedOption === option;
              const isCorrect = option === question.correctAnswer;
              let btnStyle = darkMode
                ? 'bg-[#091019] border-gray-800 text-gray-200 hover:border-[#2665DF]'
                : 'bg-[#F7F8FA] border-gray-200 text-[#111827] hover:border-[#2665DF] hover:bg-[#E8F0FF]';

              if (selectedOption !== null) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-500/15 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-500/15 border-rose-500 text-rose-700 dark:text-rose-300 font-bold';
                } else {
                  btnStyle = 'opacity-50 border-transparent';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(option)}
                  disabled={selectedOption !== null}
                  className={`w-full p-4 rounded-xl border text-left text-xs sm:text-sm font-semibold flex items-center justify-between transition-all cursor-pointer ${btnStyle}`}
                >
                  <span className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-md bg-white dark:bg-gray-800 text-center leading-6 text-xs font-bold shadow-2xs">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span>{option}</span>
                  </span>

                  {selectedOption !== null && isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                  )}
                  {selectedOption !== null && isSelected && !isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Banner */}
          {selectedOption !== null && (
            <div
              className={`p-4 rounded-xl border text-xs space-y-1.5 ${
                selectedOption === question.correctAnswer
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  : 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5">
                {selectedOption === question.correctAnswer ? 'Correct! 🌟' : 'Review Note:'}
              </div>
              <p>{question.explanation}</p>
            </div>
          )}

          {/* Next Button */}
          {selectedOption !== null && (
            <div className="pt-2 flex justify-end">
              <button
                onClick={handleNext}
                className="inline-flex items-center gap-2 px-7 py-3 rounded-xl font-bold text-xs text-white bg-[#2665DF] hover:bg-[#1F56C5] transition-colors shadow-sm cursor-pointer"
              >
                <span>{currentIndex + 1 < QUIZ_QUESTIONS.length ? 'Next Question' : 'View Results'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Results Card with circular icon badge from fss.png */
        <div
          className={`p-8 sm:p-12 rounded-3xl border text-center space-y-6 transition-colors ${
            darkMode
              ? 'bg-[#101926] border-gray-800 text-[#FFFFFF]'
              : 'bg-[#FFFFFF] border-gray-200 text-[#111827] shadow-sm'
          }`}
        >
          <div className="w-20 h-20 rounded-full bg-[#E8F0FF] text-[#2665DF] mx-auto flex items-center justify-center shadow-xs">
            <Award className="w-10 h-10 text-[#2665DF]" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#2665DF]">
              Evaluation Complete
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-[#111827] dark:text-white mt-1">
              Quiz Completed!
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              You scored {score} out of {QUIZ_QUESTIONS.length} questions correctly.
            </p>
          </div>

          <div className="text-5xl font-black text-[#2665DF]">
            {Math.round((score / QUIZ_QUESTIONS.length) * 100)}%
          </div>

          <div className="flex flex-wrap justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-[#FFFFFF] bg-[#2665DF] hover:bg-[#1F56C5] transition-colors shadow-sm cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retry Quiz</span>
            </button>
            <button
              onClick={() => onSelectSignForPractice('asl-a')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:bg-[#E8F0FF] hover:text-[#2665DF] transition-colors cursor-pointer"
            >
              <span>Practice Signs in Studio</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
