import React, { useState, useMemo } from 'react';
import { ASLSign, SignCategory } from '../types';
import { HandIllustration } from './HandIllustration';
import { Search, Filter, Camera, Volume2, X, Sparkles, CheckCircle2, ArrowRight, BookOpen } from 'lucide-react';

interface SignDictionaryProps {
  signs: ASLSign[];
  onSelectSignForPractice: (signId: string) => void;
  darkMode: boolean;
}

export const SignDictionary: React.FC<SignDictionaryProps> = ({
  signs,
  onSelectSignForPractice,
  darkMode,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeModalSign, setActiveModalSign] = useState<ASLSign | null>(null);

  // Filtered signs list
  const filteredSigns = useMemo(() => {
    return signs.filter((s) => {
      const matchesCategory = selectedCategory === 'all' || s.category === selectedCategory;
      const matchesSearch =
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.handshapeDescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.phoneticOrMeaning.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [signs, searchTerm, selectedCategory]);

  const speakSign = (sign: ASLSign) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`${sign.name}. ${sign.handshapeDescription}`);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div id="sign-dictionary-container" className="space-y-6">
      {/* Top Filter Bar */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border transition-colors ${
          darkMode
            ? 'bg-[#101926] border-gray-800 text-[#FFFFFF]'
            : 'bg-[#FFFFFF] border-gray-200 text-[#111827] shadow-sm'
        }`}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-[#E8F0FF] text-[#2665DF] flex items-center justify-center shrink-0 shadow-xs">
              <BookOpen className="w-7 h-7 text-[#2665DF]" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#2665DF]">
                Interactive Reference
              </span>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                ASL Visual Dictionary
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                Browse manual handshapes, phonetics, and spatial orientation rules across 46 signs.
              </p>
            </div>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              id="dictionary-search-input"
              type="text"
              placeholder="Search sign, letter, word..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full pl-10 pr-4 py-3 text-xs sm:text-sm font-semibold rounded-xl border focus:outline-none focus:ring-2 focus:ring-[#2665DF] transition-colors ${
                darkMode
                  ? 'bg-[#091019] border-gray-700 text-[#FFFFFF] placeholder-gray-500'
                  : 'bg-[#F7F8FA] border-gray-300 text-[#111827] placeholder-gray-400'
              }`}
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-6 pb-1 scrollbar-none">
          {[
            { id: 'all', label: 'All Signs (46)' },
            { id: 'alphabet', label: 'Alphabet A-Z (26)' },
            { id: 'numbers', label: 'Numbers 1-10 (10)' },
            { id: 'greetings', label: 'Greetings (5)' },
            { id: 'essentials', label: 'Essentials (5)' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-[#2665DF] text-[#FFFFFF] shadow-sm'
                  : darkMode
                  ? 'bg-[#091019] border border-gray-800 text-gray-300 hover:bg-[#101926]'
                  : 'bg-[#F7F8FA] border border-gray-200 text-[#111827] hover:bg-[#E8F0FF] hover:text-[#2665DF]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Signs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredSigns.map((sign) => (
          <div
            key={sign.id}
            id={`sign-card-${sign.id}`}
            onClick={() => setActiveModalSign(sign)}
            className={`group rounded-2xl border p-4 transition-all duration-200 cursor-pointer flex flex-col justify-between ${
              darkMode
                ? 'bg-[#101926] border-[#1f2d42] hover:border-[#2665DF] text-[#FFFFFF]'
                : 'bg-[#FFFFFF] border-gray-200 hover:border-[#2665DF] hover:shadow-md text-[#111827]'
            }`}
          >
            <div>
              {/* Top Card Bar */}
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#E8F0FF] text-[#2665DF]">
                  {sign.category}
                </span>
                <span className="text-[11px] font-semibold text-gray-400">
                  {sign.difficulty}
                </span>
              </div>

              {/* Hand Illustration and Symbol */}
              <div className="py-4 flex items-center justify-center gap-4">
                <HandIllustration
                  type={sign.svgType}
                  symbol={sign.symbol}
                  size={90}
                />
                <div>
                  <div className="text-2xl font-black text-[#2665DF]">
                    {sign.symbol.length <= 2 ? sign.symbol : sign.name}
                  </div>
                  <div className="text-xs font-bold mt-0.5">{sign.name}</div>
                  <div className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 line-clamp-1">
                    {sign.phoneticOrMeaning}
                  </div>
                </div>
              </div>

              <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2 mt-1">
                {sign.handshapeDescription}
              </p>
            </div>

            {/* Card Action Buttons */}
            <div className="pt-4 mt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectSignForPractice(sign.id);
                }}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold text-[#FFFFFF] bg-[#2665DF] hover:bg-[#1F56C5] transition-colors"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Practice</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  speakSign(sign);
                }}
                className="p-2 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-[#E8F0FF] hover:text-[#2665DF] transition-colors"
                title="Speak description"
                aria-label="Speak description"
              >
                <Volume2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}

        {filteredSigns.length === 0 && (
          <div className="col-span-full text-center py-12 bg-[#FFFFFF] dark:bg-[#101926] rounded-3xl border border-gray-200 dark:border-gray-800">
            <Search className="w-10 h-10 text-gray-400 mx-auto mb-3" />
            <h3 className="text-base font-bold">No signs matched "{searchTerm}"</h3>
            <p className="text-xs text-gray-500 mt-1">
              Try searching for a letter, number, or reset your filters.
            </p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#2665DF]"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Sign Detail Modal */}
      {activeModalSign && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
          onClick={() => setActiveModalSign(null)}
        >
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-8 border shadow-2xl space-y-6 ${
              darkMode
                ? 'bg-[#101926] border-[#1f2d42] text-[#FFFFFF]'
                : 'bg-[#FFFFFF] border-gray-200 text-[#111827]'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#2665DF] text-white flex items-center justify-center text-xl font-black">
                  {activeModalSign.symbol}
                </div>
                <div>
                  <h3 className="text-xl font-bold">{activeModalSign.name}</h3>
                  <span className="text-xs text-[#2665DF] font-semibold">
                    {activeModalSign.phoneticOrMeaning}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setActiveModalSign(null)}
                className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-[#1f2d42] text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex justify-center py-2">
              <HandIllustration
                type={activeModalSign.svgType}
                symbol={activeModalSign.symbol}
                size={140}
              />
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="font-bold text-gray-400 uppercase tracking-wider block mb-1">
                  Handshape & Fingers
                </span>
                <p className="p-3 rounded-xl bg-[#F7F8FA] dark:bg-[#091019] text-gray-700 dark:text-gray-300 font-medium">
                  {activeModalSign.handshapeDescription}
                </p>
              </div>

              <div>
                <span className="font-bold text-gray-400 uppercase tracking-wider block mb-1">
                  Palm Orientation
                </span>
                <div className="p-2.5 rounded-xl bg-[#E8F0FF] dark:bg-[#091019] text-[#2665DF] font-semibold border border-[#2665DF]/20">
                  {activeModalSign.palmOrientation}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#E8F0FF] dark:bg-[#091019] border border-[#2665DF]/30">
                <div className="flex items-center gap-1.5 font-bold text-[#2665DF] mb-1">
                  <Sparkles className="w-3.5 h-3.5 fill-[#2665DF]" />
                  <span>Memory Tip</span>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  "{activeModalSign.memoryTip}"
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => {
                  onSelectSignForPractice(activeModalSign.id);
                  setActiveModalSign(null);
                }}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#2665DF] hover:bg-[#1F56C5] flex items-center justify-center gap-2"
              >
                <Camera className="w-4 h-4" />
                <span>Practice in Studio</span>
              </button>
              <button
                onClick={() => speakSign(activeModalSign)}
                className="py-3 px-4 rounded-xl text-xs font-bold border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-[#E8F0FF] hover:text-[#2665DF]"
              >
                Read Aloud
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
