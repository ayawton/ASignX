import React from 'react';

interface SignSpellLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  darkMode?: boolean;
}

export const SignSpellLogo: React.FC<SignSpellLogoProps> = ({
  className = '',
  size = 'md',
  darkMode = true,
}) => {
  const iconSize = size === 'sm' ? 28 : size === 'lg' ? 44 : 36;
  const textSize =
    size === 'sm'
      ? 'text-lg'
      : size === 'lg'
      ? 'text-3xl'
      : 'text-2xl';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Cybernetic Fist Icon from fss2.png */}
      <svg
        width={iconSize}
        height={iconSize * 1.15}
        viewBox="0 0 48 56"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-sm"
      >
        {/* Hand Fist Outer Silhouette Outline */}
        <path
          d="M10 24V14C10 11.5 12 9.5 14.5 9.5C16 9.5 17.5 10.5 18 11.8C18.8 10.4 20.3 9.5 22 9.5C23.2 9.5 24.3 10.1 25 11C25.8 10 27 9.5 28.5 9.5C31 9.5 33 11.5 33 14V16C34.5 16 36 17.5 36 19.5V28C36 36 30 42 22 42C15 42 10 37 10 30V24Z"
          stroke="#FFFFFF"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Thumb curled over fingers */}
        <path
          d="M10 26C10 21 16 21 21 24C23 25.2 24.5 27 24.5 29.5C24.5 32 22 34 19 34C15 34 10 31 10 26Z"
          stroke="#FFFFFF"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Finger Creases / Knuckle separators */}
        <path d="M18 12V21" stroke="#FFFFFF" strokeWidth="1.6" strokeLinecap="round" />
        <path d="M25 11.5V22" stroke="#FFFFFF" strokeWidth="1.6" strokeLinecap="round" />
        <path d="M31.5 15V24" stroke="#FFFFFF" strokeWidth="1.6" strokeLinecap="round" />

        {/* Wrist Base Lines */}
        <path d="M14 42V52" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
        <path d="M30 42V52" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />

        {/* Circuit Tracks inside the Hand (PCB digital lines) */}
        {/* Finger 1 circuit */}
        <line x1="14.5" y1="14" x2="14.5" y2="19" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="14.5" cy="14" r="1.3" fill="#FFFFFF" />

        {/* Finger 2 circuit */}
        <line x1="21.5" y1="13" x2="21.5" y2="18" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="21.5" cy="13" r="1.3" fill="#FFFFFF" />

        {/* Finger 3 circuit */}
        <line x1="28.5" y1="13" x2="28.5" y2="18" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="28.5" cy="13" r="1.3" fill="#FFFFFF" />

        {/* Thumb & Palm trace branching */}
        <path
          d="M14 26L18 29H22"
          stroke="#FFFFFF"
          strokeWidth="1.3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="22" cy="29" r="1.3" fill="#FFFFFF" />

        {/* Lower Palm & Wrist Bus Lines */}
        <line x1="18" y1="36" x2="18" y2="50" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="18" cy="36" r="1.3" fill="#FFFFFF" />

        <line x1="22" y1="38" x2="22" y2="51" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="22" cy="38" r="1.3" fill="#FFFFFF" />

        <line x1="26" y1="36" x2="26" y2="49" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        <circle cx="26" cy="36" r="1.3" fill="#FFFFFF" />
      </svg>

      {/* Typography: "Sign" in Serif + "Spell" in Royal Blue Bold */}
      <div className="flex items-baseline tracking-tight">
        <span
          className={`font-serif font-extrabold ${textSize} tracking-normal ${
            darkMode ? 'text-white' : 'text-[#0D1522]'
          }`}
          style={{ fontFamily: 'Georgia, "Times New Roman", Merriweather, serif' }}
        >
          Sign
        </span>
        <span
          className={`font-sans font-black ${textSize} tracking-tight text-[#2665DF]`}
          style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
        >
          Spell
        </span>
      </div>
    </div>
  );
};
