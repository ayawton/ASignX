export type SignCategory = 'alphabet' | 'numbers' | 'greetings' | 'essentials';

export interface ASLSign {
  id: string;
  symbol: string;
  category: SignCategory;
  name: string;
  phoneticOrMeaning: string;
  handshapeDescription: string;
  palmOrientation: string;
  fingerPositions: string[];
  memoryTip: string;
  difficulty: 'Beginner' | 'Intermediate';
  svgType: string;
}

export interface LessonTrack {
  id: string;
  title: string;
  subtitle: string;
  category: SignCategory;
  signCount: number;
  completedCount: number;
  estimatedMinutes: number;
  level: 'Beginner' | 'Elementary' | 'Intermediate';
}

export interface UserProgress {
  streakDays: number;
  signsLearned: number;
  totalSigns: number;
  practiceMinutes: number;
  accuracyRate: number;
  currentLevel: string;
  xp: number;
}

export type ActiveTab = 'home' | 'learn' | 'practice' | 'dictionary' | 'quiz' | 'login' | 'register';
